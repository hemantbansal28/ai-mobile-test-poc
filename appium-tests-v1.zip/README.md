# Appium tests — Harness on-call mobile app

One Android smoke test, runnable locally against an emulator and on **AWS Device Farm** as a custom Appium Node.js test.

| | |
|---|---|
| Language | Node.js |
| Framework | WebdriverIO 8 + Mocha |
| Driver | Appium UiAutomator2 (Android) |
| Test | `test/specs/login.smoke.spec.js` — asserts the React Native LoginScreen mounts on first launch |

The test relies on two props added to [src/screens/Login/LoginScreen.tsx](../src/screens/Login/LoginScreen.tsx):

```tsx
<SafeAreaView testID="login-screen" accessibilityLabel="login-screen">
<Text testID="login-screen-title" accessibilityLabel="login-screen-title">
```

`accessibilityLabel` is what makes the element findable via Appium's accessibility-id selector (`~login-screen-title`) on Android. `testID` is included so the same selector will work when iOS is added later.

---

## 1. Run locally (optional — for iterating on the test)

### 1a. Build a debug APK

From the **repo root**:

```sh
npm install               # if not already done
npx patch-package
cd android
./gradlew assembleDebug
```

The APK lands at:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

### 1b. Start an Appium server

```sh
npm install -g appium
appium driver install uiautomator2
appium               # listens on http://127.0.0.1:4723
```

### 1c. Boot an Android emulator (or attach a device)

```sh
adb devices          # confirm at least one device is online
```

### 1d. Run the test

```sh
cd appium-tests
npm install
npm run test:local:android
```

Override the APK path with `APP_APK_PATH=/abs/path/to.apk` if needed.

---

## 2. Run on AWS Device Farm

Device Farm needs **two uploads** plus a **test-spec YAML**:

1. **The app** — a signed Android APK.
2. **The test package** — a zip of this folder *without* `node_modules`.
3. **The test spec** — [test-spec.yml](./test-spec.yml).

### 2a. Build a signable APK

A debug APK is fine for a first Device Farm run (Device Farm accepts unsigned/debug-signed APKs). From the repo root:

```sh
cd android
./gradlew assembleDebug
# → android/app/build/outputs/apk/debug/app-debug.apk
```

If you want a release-signed APK instead:

```sh
cd android
./gradlew assembleRelease
# → android/app/build/outputs/apk/release/app-release.apk
# (requires android/app/release.keystore and signing config in build.gradle)
```

### 2b. Bundle the test package

From the **repo root**:

```sh
cd appium-tests
rm -rf node_modules           # IMPORTANT: Device Farm runs `npm install` itself
zip -r test-bundle.zip . -x "node_modules/*" "*.zip"
```

You should now have `appium-tests/test-bundle.zip` containing:

```
package.json
wdio.devicefarm.conf.js
test-spec.yml
test/specs/login.smoke.spec.js
...
```

### 2c. Upload everything to Device Farm

**Console route** (recommended for the first run):

1. AWS Console → **Device Farm** → create or open a project.
2. Click **Create a new run**.
3. **Choose application**: upload `android/app/build/outputs/apk/debug/app-debug.apk`. Platform = **Android**.
4. **Configure** test:
   - Test framework: **Appium Node.js**.
   - Upload test package: `appium-tests/test-bundle.zip`.
   - Choose **"Use a Test Spec"** → upload `appium-tests/test-spec.yml`.
5. **Select devices**: pick a single Android device pool (a Pixel on Android 12/13 is a safe first choice).
6. **Review and start run.**

**CLI route** (for repeat runs / CI):

```sh
# 1. Create upload slots and PUT the artifacts
aws devicefarm create-upload --project-arn <PROJECT_ARN> \
  --name app-debug.apk --type ANDROID_APP
# → use the returned `url` to PUT android/app/build/outputs/apk/debug/app-debug.apk
curl -T android/app/build/outputs/apk/debug/app-debug.apk "<presigned-url>"

aws devicefarm create-upload --project-arn <PROJECT_ARN> \
  --name test-bundle.zip --type APPIUM_NODE_TEST_PACKAGE
curl -T appium-tests/test-bundle.zip "<presigned-url>"

aws devicefarm create-upload --project-arn <PROJECT_ARN> \
  --name test-spec.yml --type APPIUM_NODE_TEST_SPEC
curl -T appium-tests/test-spec.yml "<presigned-url>"

# 2. Schedule the run (wait until all three uploads report status=SUCCEEDED first)
aws devicefarm schedule-run \
  --project-arn <PROJECT_ARN> \
  --app-arn <APP_UPLOAD_ARN> \
  --device-pool-arn <DEVICE_POOL_ARN> \
  --name "oncall-smoke-$(date +%s)" \
  --test "type=APPIUM_NODE,testPackageArn=<TEST_PKG_ARN>,testSpecArn=<TEST_SPEC_ARN>"
```

### 2d. Watch the run on the dashboard

In the Device Farm console, open the run → expand the device → expand the **Test** phase. You should see the `spec` reporter output ending with:

```
✓ launches and renders the Login screen
1 passing
```

The full WebdriverIO log is downloadable from the **Files** tab on the test result page.

---

## What this test does and does NOT verify

**Does:**
- App starts on the device, RN bundle loads, LoginScreen component mounts.

**Does NOT (yet):**
- Visibility of the login screen (the DND-permission modal renders on top on first Android launch and would need to be dismissed first).
- Any actual login flow.
- iOS — adding iOS is a follow-up: add an iOS `capabilities` block to a new `wdio.devicefarm.ios.conf.js`, build a `.ipa`, and create a second Device Farm run.

---

## Troubleshooting

- **`unknown error: Unable to find element with accessibility id 'login-screen-title'`**
  Confirm the LoginScreen edits at `src/screens/Login/LoginScreen.tsx` made it into the APK you uploaded. Rebuild after editing.
- **`Could not start a new session` / Appium connection refused on Device Farm**
  Make sure you selected **"Use a Test Spec"** when uploading — without it, Device Farm runs its default Appium scaffolding and ignores `wdio.devicefarm.conf.js`.
- **`Cannot find module 'webdriverio'`**
  You zipped `node_modules` into the bundle and exceeded the 1 GB limit, or `npm install` failed in the `install` phase. Re-bundle without `node_modules` and check the install-phase log.
