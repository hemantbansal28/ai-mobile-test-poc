// One smoke test: the React Native app launches and the LoginScreen mounts.
//
// Why "waitForExist" instead of "waitForDisplayed":
//   On a fresh Android install, the app shows a DND-permission modal on top of
//   the LoginScreen (see src/App.tsx). The LoginScreen is still mounted in the
//   React tree underneath the modal, just not visible. We assert that the
//   LoginScreen element EXISTS in the accessibility tree — that is the
//   definition of "the login screen rendered". A future, separate test can
//   dismiss the DND modal and assert visibility.
//
// Locator strategy:
//   We use the WebdriverIO "~" prefix (accessibility id). React Native's
//   `accessibilityLabel` prop maps to content-desc on Android, which is what
//   Appium's UiAutomator2 driver matches against accessibility-id selectors.
//   testID is also set on the same elements so the same selectors will work
//   when we add iOS later.
const assert = require('assert');

describe('Harness on-call app — smoke', function () {
  it('launches and renders the Login screen', async function () {
    const loginTitle = await $('~login-screen-title');
    await loginTitle.waitForExist({
      timeout: 90000,
      timeoutMsg:
        'LoginScreen did not mount within 90s — RN bundle may have failed to load on the device.',
    });

    assert.strictEqual(
      await loginTitle.isExisting(),
      true,
      'Expected LoginScreen title element to exist in the accessibility tree',
    );
  });
});
