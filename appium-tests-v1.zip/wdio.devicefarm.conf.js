// WebdriverIO config for AWS Device Farm (custom test environment).
//
// AWS Device Farm starts an Appium server for us and exposes the device/app
// details via environment variables. We only need to point WebdriverIO at the
// local Appium server and read the capabilities from those env vars.
//
// Env vars provided by Device Farm at runtime:
//   DEVICEFARM_DEVICE_PLATFORM_NAME   e.g. "Android"
//   DEVICEFARM_DEVICE_NAME            human-readable device name
//   DEVICEFARM_DEVICE_UDID            device UDID
//   DEVICEFARM_DEVICE_OS_VERSION      e.g. "13"
//   DEVICEFARM_APP_PATH               absolute path to the uploaded .apk
//   DEVICEFARM_TEST_PACKAGE_PATH      where this test bundle is unpacked
//   DEVICEFARM_LOG_DIR                where to write artifacts
const path = require('path');

const platformName = process.env.DEVICEFARM_DEVICE_PLATFORM_NAME || 'Android';

exports.config = {
  runner: 'local',

  hostname: '127.0.0.1',
  port: 4723,
  path: '/wd/hub',

  specs: [path.join(__dirname, 'test', 'specs', '**', '*.spec.js')],
  maxInstances: 1,

  capabilities: [
    {
      platformName,
      'appium:automationName': 'UiAutomator2',
      'appium:deviceName': process.env.DEVICEFARM_DEVICE_NAME || 'Android Device',
      'appium:udid': process.env.DEVICEFARM_DEVICE_UDID,
      'appium:platformVersion': process.env.DEVICEFARM_DEVICE_OS_VERSION,
      'appium:app': process.env.DEVICEFARM_APP_PATH,
      'appium:autoGrantPermissions': true,
      'appium:newCommandTimeout': 240,
      // Give RN's first launch (bundle load + JS init) plenty of time.
      'appium:appWaitDuration': 60000,
      'appium:adbExecTimeout': 60000,
      'appium:uiautomator2ServerInstallTimeout': 60000,
      'appium:uiautomator2ServerLaunchTimeout': 60000,
    },
  ],

  logLevel: 'info',
  bail: 0,
  waitforTimeout: 60000,
  connectionRetryTimeout: 180000,
  connectionRetryCount: 3,

  framework: 'mocha',
  reporters: ['spec'],

  mochaOpts: {
    ui: 'bdd',
    timeout: 180000,
  },
};
