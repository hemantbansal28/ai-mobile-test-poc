// WebdriverIO config for running the same spec against a local Android emulator
// or attached device. Useful for iterating on tests before pushing to Device Farm.
//
// Prerequisites:
//   - A local Appium 2.x server running on http://127.0.0.1:4723/
//       npm i -g appium
//       appium driver install uiautomator2
//       appium
//   - A booted Android emulator OR a USB-attached device (adb devices)
//   - A built debug APK at android/app/build/outputs/apk/debug/app-debug.apk
//     (produced by `cd android && ./gradlew assembleDebug` from the repo root)
const path = require('path');

const APK_PATH =
  process.env.APP_APK_PATH ||
  path.resolve(
    __dirname,
    '..',
    'android',
    'app',
    'build',
    'outputs',
    'apk',
    'debug',
    'app-debug.apk',
  );

exports.config = {
  runner: 'local',

  hostname: '127.0.0.1',
  port: 4723,
  path: '/',

  specs: [path.join(__dirname, 'test', 'specs', '**', '*.spec.js')],
  maxInstances: 1,

  capabilities: [
    {
      platformName: 'Android',
      'appium:automationName': 'UiAutomator2',
      'appium:deviceName': process.env.ANDROID_DEVICE_NAME || 'Android Emulator',
      'appium:app': APK_PATH,
      'appium:autoGrantPermissions': true,
      'appium:newCommandTimeout': 240,
      'appium:appWaitDuration': 60000,
    },
  ],

  logLevel: 'info',
  waitforTimeout: 30000,
  connectionRetryTimeout: 120000,
  connectionRetryCount: 3,

  framework: 'mocha',
  reporters: ['spec'],

  mochaOpts: {
    ui: 'bdd',
    timeout: 180000,
  },
};
